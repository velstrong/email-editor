'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _DingtalkCircleFilled = _interopRequireDefault(require('./lib/icons/DingtalkCircleFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _DingtalkCircleFilled;
  exports.default = _default;
  module.exports = _default;