'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _BugOutlined = _interopRequireDefault(require('./lib/icons/BugOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _BugOutlined;
  exports.default = _default;
  module.exports = _default;