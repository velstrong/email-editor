'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _CloudSyncOutlined = _interopRequireDefault(require('./lib/icons/CloudSyncOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _CloudSyncOutlined;
  exports.default = _default;
  module.exports = _default;