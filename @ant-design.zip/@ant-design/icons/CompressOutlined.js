'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _CompressOutlined = _interopRequireDefault(require('./lib/icons/CompressOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _CompressOutlined;
  exports.default = _default;
  module.exports = _default;