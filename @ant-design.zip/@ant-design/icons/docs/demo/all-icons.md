## all-icons
<code src="../examples/all-icons.tsx">
