## basic
<code src="../examples/basic.tsx">
