'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _CopyrightTwoTone = _interopRequireDefault(require('./lib/icons/CopyrightTwoTone'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _CopyrightTwoTone;
  exports.default = _default;
  module.exports = _default;