'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _BehanceSquareOutlined = _interopRequireDefault(require('./lib/icons/BehanceSquareOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _BehanceSquareOutlined;
  exports.default = _default;
  module.exports = _default;