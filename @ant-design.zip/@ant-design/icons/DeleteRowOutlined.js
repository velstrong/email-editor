'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _DeleteRowOutlined = _interopRequireDefault(require('./lib/icons/DeleteRowOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _DeleteRowOutlined;
  exports.default = _default;
  module.exports = _default;