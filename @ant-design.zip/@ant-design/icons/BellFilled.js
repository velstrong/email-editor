'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _BellFilled = _interopRequireDefault(require('./lib/icons/BellFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _BellFilled;
  exports.default = _default;
  module.exports = _default;