'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _AccountBookFilled = _interopRequireDefault(require('./lib/icons/AccountBookFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _AccountBookFilled;
  exports.default = _default;
  module.exports = _default;