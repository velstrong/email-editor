'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _DesktopOutlined = _interopRequireDefault(require('./lib/icons/DesktopOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _DesktopOutlined;
  exports.default = _default;
  module.exports = _default;