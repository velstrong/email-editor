'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _DollarOutlined = _interopRequireDefault(require('./lib/icons/DollarOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _DollarOutlined;
  exports.default = _default;
  module.exports = _default;