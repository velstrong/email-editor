'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _DotChartOutlined = _interopRequireDefault(require('./lib/icons/DotChartOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _DotChartOutlined;
  exports.default = _default;
  module.exports = _default;