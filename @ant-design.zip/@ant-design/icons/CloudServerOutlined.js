'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _CloudServerOutlined = _interopRequireDefault(require('./lib/icons/CloudServerOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _CloudServerOutlined;
  exports.default = _default;
  module.exports = _default;