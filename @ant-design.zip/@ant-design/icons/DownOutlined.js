'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _DownOutlined = _interopRequireDefault(require('./lib/icons/DownOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _DownOutlined;
  exports.default = _default;
  module.exports = _default;