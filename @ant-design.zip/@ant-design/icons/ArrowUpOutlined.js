'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _ArrowUpOutlined = _interopRequireDefault(require('./lib/icons/ArrowUpOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _ArrowUpOutlined;
  exports.default = _default;
  module.exports = _default;