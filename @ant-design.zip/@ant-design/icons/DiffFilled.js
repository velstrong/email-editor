'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _DiffFilled = _interopRequireDefault(require('./lib/icons/DiffFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _DiffFilled;
  exports.default = _default;
  module.exports = _default;