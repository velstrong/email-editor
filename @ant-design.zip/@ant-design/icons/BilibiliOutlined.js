'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _BilibiliOutlined = _interopRequireDefault(require('./lib/icons/BilibiliOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _BilibiliOutlined;
  exports.default = _default;
  module.exports = _default;