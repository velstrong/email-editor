'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _CopyTwoTone = _interopRequireDefault(require('./lib/icons/CopyTwoTone'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _CopyTwoTone;
  exports.default = _default;
  module.exports = _default;