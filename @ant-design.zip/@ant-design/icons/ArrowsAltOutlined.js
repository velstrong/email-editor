'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _ArrowsAltOutlined = _interopRequireDefault(require('./lib/icons/ArrowsAltOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _ArrowsAltOutlined;
  exports.default = _default;
  module.exports = _default;