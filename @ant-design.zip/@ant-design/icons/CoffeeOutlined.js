'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _CoffeeOutlined = _interopRequireDefault(require('./lib/icons/CoffeeOutlined'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _CoffeeOutlined;
  exports.default = _default;
  module.exports = _default;