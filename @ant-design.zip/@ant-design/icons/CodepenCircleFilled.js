'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _CodepenCircleFilled = _interopRequireDefault(require('./lib/icons/CodepenCircleFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _CodepenCircleFilled;
  exports.default = _default;
  module.exports = _default;