'use strict';
  Object.defineProperty(exports, "__esModule", {
    value: true
  });
  exports.default = void 0;
  
  var _ChromeFilled = _interopRequireDefault(require('./lib/icons/ChromeFilled'));
  
  function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }
  
  var _default = _ChromeFilled;
  exports.default = _default;
  module.exports = _default;